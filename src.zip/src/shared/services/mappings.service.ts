import { Injectable } from '@angular/core';

import { IThread, IComment,IAnnouncement } from '../interfaces';
import { ItemsService } from '../services/items.service';

@Injectable()
export class MappingsService {

    constructor(private itemsService: ItemsService) { }

    getThreads(snapshot: any): Array<IThread> {
        let threads: Array<IThread> = [];
        if (snapshot.val() == null)
            return threads;

        let list = snapshot.val();

        Object.keys(snapshot.val()).map((key: any) => {
            let thread: any = list[key];
            threads.push({
                key: key,
                title: thread.title,
                question: thread.question,
                category: thread.category,
                dateCreated: thread.dateCreated,
                user: { uid: thread.user.uid, username: thread.user.username },
                comments: thread.comments == null ? 0 : thread.comments
            });
        });

        return threads;
    }

    getAnnouncements(snapshot: any): Array<IAnnouncement> {
        let announcements: Array<IAnnouncement> = [];
        if (snapshot.val() == null)
            return announcements;

        let list = snapshot.val();

        Object.keys(snapshot.val()).map((key: any) => {
            let announcements: any = list[key];
            announcements.push({
                key: key,
                title: announcements.title,
                question: announcements.question,
                category: announcements.category,
                dateCreated: announcements.dateCreated,
                user: { uid: announcements.user.uid, username: announcements.user.username },
                comments: announcements.comments == null ? 0 : announcements.comments
            });
        });

        return announcements;
    }


    getThread(snapshot: any, key: string): IThread {

        let thread: IThread = {
            key: key,
            title: snapshot.title,
            question: snapshot.question,
            category: snapshot.category,
            dateCreated: snapshot.dateCreated,
            user: snapshot.user,
            comments: snapshot.comments == null ? 0 : snapshot.comments
        };

        return thread;
    }

    getAnnouncement(snapshot: any, key: string): IAnnouncement {

        let announcement: IAnnouncement = {
            key: key,
            title: snapshot.title,
            question: snapshot.question,
            category: snapshot.category,
            dateCreated: snapshot.dateCreated,
            user: snapshot.user,
            comments: snapshot.comments == null ? 0 : snapshot.comments
        };

        return announcement;
    }


    getComments(snapshot: any): Array<IComment> {
        let comments: Array<IComment> = [];
        if (snapshot.val() == null)
            return comments;

        let list = snapshot.val();

        Object.keys(snapshot.val()).map((key: any) => {
            let comment: any = list[key];
            //console.log(comment.votes);
            this.itemsService.groupByBoolean(comment.votes, true);

            comments.push({
                key: key,
                text: comment.text,
                thread: comment.thread,
                dateCreated: comment.dateCreated,
                user: comment.user,
                votesUp: this.itemsService.groupByBoolean(comment.votes, true),
                votesDown: this.itemsService.groupByBoolean(comment.votes, false)
            });
        });

        return comments;
    }

    getComment(snapshot: any, commentKey: string): IComment {
        let comment: IComment;

        if (snapshot.val() == null)
            return null;

        let snapshotComment = snapshot.val();
        console.log(snapshotComment);
        comment = {
            key: commentKey,
            text: snapshotComment.text,
            thread: snapshotComment.thread,
            dateCreated: snapshotComment.dateCreated,
            user: snapshotComment.user,
            votesUp: this.itemsService.groupByBoolean(snapshotComment.votes, true),
            votesDown: this.itemsService.groupByBoolean(snapshotComment.votes, false)
        };

        return comment;
    }

}